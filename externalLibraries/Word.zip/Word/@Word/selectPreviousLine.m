function selectPreviousLine( this )

goToPreviousLine( this );
selectCurrentLine(this);
