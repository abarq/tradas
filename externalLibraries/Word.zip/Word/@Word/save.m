function this = save(this)

% Save existing file:
invoke(this.wordHandle,'Save');