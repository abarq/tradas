function goToEndOfLine( this )

this.actxWord.Selection.EndKey;

end