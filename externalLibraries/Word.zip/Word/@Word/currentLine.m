function n = currentLine( this )

n = this.actxWord.Selection.Information(10);

end