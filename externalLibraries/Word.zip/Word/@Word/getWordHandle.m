function h = getWordHandle(this)

h = this.actxWord;