function goToPage( this, n )

this.actxWord.Selection.GoTo(1, 1, n, '');

end