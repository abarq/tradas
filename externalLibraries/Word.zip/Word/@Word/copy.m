function copy(this)

invoke(this.actxWord.Selection,'Copy');