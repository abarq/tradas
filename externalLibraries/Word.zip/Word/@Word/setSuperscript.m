function setSuperscript( this, ok )

set( this.actxWord.Selection.Range.Style.Font, 'Superscript', ok );
