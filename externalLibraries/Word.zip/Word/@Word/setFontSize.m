function setFontSize( this, size )

set( this.actxWord.Selection.Range.Style.Font, 'Size', size );
