function goToLine(this,n)

goTo(this,'wdGoToLine','wdGoToAbsolute',n);