function selectAll( this )

this.actxWord.Selection.WholeStory;


%         start = get( actxWord.activedocument.content, 'Start' );
%         end1  = get( actxWord.activedocument.content, 'End' );
%         set( actxWord.Selection, 'Start', start );
%         set( actxWord.Selection, 'End' ,end1 );

end