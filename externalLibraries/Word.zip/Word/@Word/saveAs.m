function this = saveAs(this,file)

this.wordHandle.SaveAs2(file);
