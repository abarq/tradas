function s = style( this )

s = get( this.actxWord.Selection.Range.Style.NameLocal );