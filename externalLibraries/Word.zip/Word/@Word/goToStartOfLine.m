function goToStartOfLine( this )

this.actxWord.Selection.HomeKey;

end