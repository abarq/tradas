function setUnderline( this, ok )

set( this.actxWord.Selection.Range.Style.Font, 'Underline', ok );
