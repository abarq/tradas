function setBold( this, ok )

set( this.actxWord.Selection.Range.Style.Font, 'Bold', ok );
