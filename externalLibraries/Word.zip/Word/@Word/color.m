function color( this )


get( this.actxWord.Selection.Range.Style.Font, 'HighlightColorIndex' );