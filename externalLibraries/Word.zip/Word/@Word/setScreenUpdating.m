function setScreenUpdating( this, updating )

set(this.actxWord,'ScreenUpdating',updating);