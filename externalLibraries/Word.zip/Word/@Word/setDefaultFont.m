function setDefaultFont( this )

this.actxWord.Selection.Style.Font = this.defaultFont;


