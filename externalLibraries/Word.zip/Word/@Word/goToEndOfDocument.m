function goToEndOfDocument(this)

selectAll(this);
goToLine( this, numberOfLines(this) );