function setSubscript( this, ok )

set( this.actxWord.Selection.Range.Style.Font, 'Subscript', ok );
