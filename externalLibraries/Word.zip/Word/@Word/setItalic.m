function setItalic( this, ok )

set( this.actxWord.Selection.Range.Style.Font, 'Italic', ok );
