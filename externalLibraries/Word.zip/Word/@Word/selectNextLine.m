function selectNextLine( this )

goToNextLine( this );
selectCurrentLine(this);
