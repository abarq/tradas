function paste(this)

invoke(this.actxWord.Selection,'Paste');