function setVisible( this, visible )

this.actxWord.Visible = visible;

end