function clear( this )

selectAll(this);

this.actxWord.Selection.TypeBackspace;

end